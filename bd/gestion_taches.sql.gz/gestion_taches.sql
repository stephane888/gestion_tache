-- Adminer 4.8.1 MySQL 5.5.5-10.5.10-MariaDB-2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `gestion_project_configs`;
CREATE TABLE `gestion_project_configs` (
  `idconfigs` int(11) NOT NULL AUTO_INCREMENT,
  `testconfigs` text NOT NULL,
  `idcontents` int(11) NOT NULL,
  PRIMARY KEY (`idconfigs`),
  KEY `idcontents` (`idcontents`),
  CONSTRAINT `gestion_project_configs_ibfk_1` FOREIGN KEY (`idcontents`) REFERENCES `gestion_project_contents` (`idcontents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gestion_project_contents`;
CREATE TABLE `gestion_project_contents` (
  `idcontents` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext NOT NULL,
  `titre` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp(),
  `type` varchar(150) NOT NULL,
  PRIMARY KEY (`idcontents`),
  KEY `type` (`type`),
  CONSTRAINT `gestion_project_contents_ibfk_1` FOREIGN KEY (`type`) REFERENCES `gestion_project_type` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gestion_project_hierachie`;
CREATE TABLE `gestion_project_hierachie` (
  `idhierachie` int(11) NOT NULL AUTO_INCREMENT,
  `idcontentsparent` int(11) NOT NULL,
  `ordre` int(5) NOT NULL,
  `level` int(5) NOT NULL,
  `idcontents` int(11) NOT NULL,
  PRIMARY KEY (`idhierachie`),
  KEY `idcontentsparent` (`idcontentsparent`),
  KEY `idcontents` (`idcontents`),
  CONSTRAINT `gestion_project_hierachie_ibfk_2` FOREIGN KEY (`idcontents`) REFERENCES `gestion_project_contents` (`idcontents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gestion_project_times`;
CREATE TABLE `gestion_project_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_depart_proposer` int(11) DEFAULT NULL,
  `date_fin_proposer` int(11) DEFAULT NULL,
  `date_fin_reel` int(11) DEFAULT NULL,
  `status` int(2) NOT NULL,
  `temps_pause` int(5) NOT NULL DEFAULT 0,
  `raison` text DEFAULT NULL,
  `idcontents` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idcontents` (`idcontents`),
  CONSTRAINT `gestion_project_times_ibfk_1` FOREIGN KEY (`idcontents`) REFERENCES `gestion_project_contents` (`idcontents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gestion_project_type`;
CREATE TABLE `gestion_project_type` (
  `name` varchar(150) NOT NULL,
  `label` varchar(150) NOT NULL,
  `description` tinytext NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2021-05-31 06:49:04
